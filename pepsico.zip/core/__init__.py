"""
核心商業邏輯模組包：
- cleaning: 通用清洗與前處理
- risk: 風險計算主流程
- prompt: LLM 稽核 Prompt 產生器
"""


