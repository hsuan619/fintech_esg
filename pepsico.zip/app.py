import streamlit as st

from ui import tab_generate_prompt, tab_pdf_to_md, tab_risk_assessment


# 設定頁面配置 (必須是第一個 Streamlit 指令)
st.set_page_config(page_title="ESG 漂綠稽核小幫手", layout="wide", page_icon="🌱")

# ==========================================
# Streamlit 網頁介面 (Web Interface)
# ==========================================

st.title("🌱 ESG 報告書漂綠稽核小幫手")
st.markdown(
    """
本工具提供從 **PDF 報告轉換** 到 **績效風險稽核** 的一站式流程。
請依序使用下方分頁功能：
"""
)

# 建立三個主要頁籤
tab1, tab2, tab3 = st.tabs(
    [
        "📄 1. 報告轉換 (PDF to MD)",
        "🤖 2. 產生稽核 Prompt",
        "📊 3. 績效追蹤與風險評估",
    ]
)

# ------------------------------------------
# Tab 1: 報告轉換 (PDF -> Markdown)
# ------------------------------------------
with tab1:
    tab_pdf_to_md.render()

# ------------------------------------------
# Tab 2: 產生稽核 Prompt
# ------------------------------------------
with tab2:
    tab_generate_prompt.render()

# ------------------------------------------
# Tab 3: 績效追蹤與風險評估 (核心邏輯區)
# ------------------------------------------
with tab3:
    tab_risk_assessment.render()


